import { Heading, HStack, Image, Text, VStack } from '@chakra-ui/react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowRight } from '@fortawesome/free-solid-svg-icons'
import React from 'react'

const Card = ({ title, description, imageSrc }) => {
	return (
		<HStack backgroundColor='#fff' borderRadius='5px' alignItems='flex-start'>
			<VStack>
				<Image src={imageSrc} borderRadius='5px' />
				<VStack p={3} color='#000'>
					<Heading fontSize='16px'>{title}</Heading>
					<Text fontSize='12px' color='grey'>
						{description}
					</Text>
					<Text fontSize='12px'>
						See more <FontAwesomeIcon icon={faArrowRight} size='sm' />
					</Text>
				</VStack>
			</VStack>
		</HStack>
	)
}

export default Card
